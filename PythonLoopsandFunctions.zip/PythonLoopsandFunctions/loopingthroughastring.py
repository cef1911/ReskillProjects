# Looping Through a String

# Even strings are iterable objects, they contain a sequence of characters:

# Example

for x in "banana":
  print(x)
